#!/usr/bin/env bash
# tg2rub fast installer: Ubuntu 22.04 amd64; no C++ build on the VPS.
set -Eeuo pipefail
umask 077

[[ "$(id -u)" -eq 0 ]] || { echo "Run as root: bash install.sh" >&2; exit 1; }
HERE="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
ROOT=/opt/tg2rub
APP="$ROOT/app"
BIN_SOURCE="${TG2RUB_BOT_API_BIN:-$HERE/prebuilt/telegram-bot-api}"
SUM_SOURCE="${BIN_SOURCE}.sha256"
fail() { echo "ERROR: $*" >&2; exit 1; }

[[ -f "$HERE/bot.py" && -f "$HERE/fileops.py" && -f "$HERE/login_rubika.py" && -f "$HERE/requirements.txt" ]] || fail "Project files are incomplete. Extract the full package first."
[[ "$(. /etc/os-release && echo "$VERSION_ID")" == "22.04" ]] || fail "This package targets Ubuntu 22.04."
[[ "$(dpkg --print-architecture)" == "amd64" ]] || fail "The supplied binary targets amd64/x86_64 only."
[[ -f "$BIN_SOURCE" ]] || fail "Prebuilt telegram-bot-api binary is missing. Build it with the included GitHub Actions workflow and place it at $BIN_SOURCE. No compilation will run on this VPS."
[[ -f "$SUM_SOURCE" ]] || fail "Binary checksum file is missing: $SUM_SOURCE"
(cd "$(dirname "$BIN_SOURCE")" && sha256sum -c "$(basename "$SUM_SOURCE")") || fail "Bot API checksum verification failed."
chmod 0755 "$BIN_SOURCE"  # GitHub artifact ZIP extraction may not preserve executable bits.

# Never silently overwrite or partially regenerate credentials.
ENV_EXISTS=0; API_EXISTS=0
[[ -s "$APP/.env" ]] && ENV_EXISTS=1
[[ -s /etc/tg2rub/tgapi.env ]] && API_EXISTS=1
if [[ $ENV_EXISTS -ne $API_EXISTS ]]; then
  fail "Only one credential file exists. Refusing to overwrite partial configuration; restore both files or back them up first."
fi
if [[ $ENV_EXISTS -eq 1 ]]; then
  [[ ! -L "$APP/.env" && ! -L /etc/tg2rub/tgapi.env ]] || fail "Credential files must not be symbolic links."
  grep -Eq '^BOT_TOKEN=[0-9]{6,}:[A-Za-z0-9_-]{20,}$' "$APP/.env" || fail "Existing Bot Token is missing/invalid; refusing overwrite."
  grep -Eq '^ADMIN_IDS=[0-9]+(,[0-9]+)*$' "$APP/.env" || fail "Existing ADMIN_IDS is missing/invalid; refusing overwrite."
  grep -Eq '^TELEGRAM_API_ID=[0-9]+$' /etc/tg2rub/tgapi.env || fail "Existing API_ID is missing/invalid; refusing overwrite."
  grep -Eq '^TELEGRAM_API_HASH=[A-Fa-f0-9]{32}$' /etc/tg2rub/tgapi.env || fail "Existing API_HASH is missing/invalid; refusing overwrite."
  echo ">> Existing complete credentials detected; preserving them."
else
  echo ">> First-time credentials setup (secret values are hidden)"
  read -rsp "Telegram Bot Token: " BOT_TOKEN; echo
  read -rp "Telegram Admin numeric ID (multiple: comma-separated): " ADMIN_ID
  read -rp "Telegram API_ID: " API_ID
  read -rsp "Telegram API_HASH: " API_HASH; echo
  [[ "$BOT_TOKEN" =~ ^[0-9]{6,}:[A-Za-z0-9_-]{20,}$ ]] || fail "Bot token format is invalid."
  [[ "$ADMIN_ID" =~ ^[0-9]+(,[0-9]+)*$ ]] || fail "Admin ID must be numeric."
  [[ "$API_ID" =~ ^[0-9]+$ ]] || fail "API_ID must be numeric."
  [[ "$API_HASH" =~ ^[A-Fa-f0-9]{32}$ ]] || fail "API_HASH must be 32 hexadecimal characters."
fi

echo ">> Checking runtime packages (no compiler, CMake or source build)"
export DEBIAN_FRONTEND=noninteractive
PACKAGES=(python3 python3-venv python3-pip ca-certificates curl libssl3 zlib1g libstdc++6)
MISSING=()
for pkg in "${PACKAGES[@]}"; do
  dpkg-query -W -f='${Status}' "$pkg" 2>/dev/null | grep -q 'install ok installed' || MISSING+=("$pkg")
done
if ((${#MISSING[@]})); then
  apt-get update
  apt-get install -y --no-install-recommends "${MISSING[@]}"
else
  echo ">> Runtime packages already installed; skipping apt update."
fi

# Verify dynamic dependencies only after runtime libraries are present.
command -v ldd >/dev/null || fail "ldd is unavailable."
if ldd "$BIN_SOURCE" 2>&1 | grep -q 'not found'; then
  ldd "$BIN_SOURCE" >&2
  fail "The prebuilt binary has missing runtime libraries; use the Ubuntu 22.04 GitHub Actions artifact."
fi
"$BIN_SOURCE" --help >/dev/null 2>&1 || fail "telegram-bot-api binary failed its startup check."

id tg2rub >/dev/null 2>&1 || useradd --system --create-home --home-dir "$ROOT" --shell /usr/sbin/nologin tg2rub
install -d -o tg2rub -g tg2rub "$APP" "$ROOT/work" "$ROOT/tgdata" "$ROOT/tgtmp"
install -d -o root -g root -m 0700 /etc/tg2rub

if [[ $ENV_EXISTS -eq 0 ]]; then
  TMP_APP_ENV="$(mktemp)"; TMP_API_ENV="$(mktemp)"
  trap 'rm -f "${TMP_APP_ENV:-}" "${TMP_API_ENV:-}"' EXIT
  printf 'BOT_TOKEN=%s\nADMIN_IDS=%s\nAPI_BASE=http://127.0.0.1:8081\nWORK_DIR=%s\nMAX_FILE_GB=4\nRUBIKA_MAX_MB=1900\nAUTO_DELETE=1\nZIP_LEVEL=0\nUPLOAD_TIMEOUT_MIN=180\nSTALE_HOURS=24\nUPLOAD_RETRIES=3\nUPLOAD_RETRY_BASE_SEC=5\n' \
    "$BOT_TOKEN" "$ADMIN_ID" "$ROOT/work" > "$TMP_APP_ENV"
  printf 'TELEGRAM_API_ID=%s\nTELEGRAM_API_HASH=%s\n' "$API_ID" "$API_HASH" > "$TMP_API_ENV"
  install -o tg2rub -g tg2rub -m 0600 "$TMP_APP_ENV" "$APP/.env"
  install -o root -g root -m 0600 "$TMP_API_ENV" /etc/tg2rub/tgapi.env
  rm -f "$TMP_APP_ENV" "$TMP_API_ENV"
  unset BOT_TOKEN ADMIN_ID API_ID API_HASH
fi

# Copy only code/config templates; never copy sessions, .env, work files or caches.
install -o tg2rub -g tg2rub -m 0644 "$HERE/bot.py" "$APP/bot.py"
install -o tg2rub -g tg2rub -m 0644 "$HERE/fileops.py" "$APP/fileops.py"
install -o tg2rub -g tg2rub -m 0644 "$HERE/login_rubika.py" "$APP/login_rubika.py"
install -o tg2rub -g tg2rub -m 0644 "$HERE/requirements.txt" "$APP/requirements.txt"
if [[ -f "$HERE/logout_cloud_bot.py" ]]; then
  install -o root -g root -m 0700 "$HERE/logout_cloud_bot.py" /usr/local/sbin/tg2rub-logout-cloud
fi
install -o root -g root -m 0755 "$BIN_SOURCE" /usr/local/bin/telegram-bot-api

if [[ ! -x "$APP/venv/bin/python" ]]; then
  python3 -m venv "$APP/venv"
fi
"$APP/venv/bin/python" -m pip install --disable-pip-version-check --no-warn-script-location --prefer-binary -r "$APP/requirements.txt"

chown -R tg2rub:tg2rub "$ROOT"
chmod 0600 "$APP/.env"
chmod 0700 "$ROOT/work" "$ROOT/tgdata" "$ROOT/tgtmp"
chown root:root /etc/tg2rub/tgapi.env
chmod 0600 /etc/tg2rub/tgapi.env

cat > /etc/systemd/system/tgapi.service <<UNIT
[Unit]
Description=Local Telegram Bot API
After=network-online.target
Wants=network-online.target
[Service]
Type=simple
User=tg2rub
Group=tg2rub
EnvironmentFile=/etc/tg2rub/tgapi.env
ExecStart=/usr/local/bin/telegram-bot-api --local --http-ip-address=127.0.0.1 --http-port=8081 --dir=$ROOT/tgdata --temp-dir=$ROOT/tgtmp
Restart=on-failure
RestartSec=3
LimitNOFILE=65536
NoNewPrivileges=true
ProtectSystem=strict
ProtectHome=true
ReadWritePaths=$ROOT
PrivateTmp=true
[Install]
WantedBy=multi-user.target
UNIT

cat > /etc/systemd/system/tg2rub.service <<UNIT
[Unit]
Description=Telegram to Rubika file bridge
After=network-online.target tgapi.service
Wants=network-online.target
Requires=tgapi.service
[Service]
Type=simple
User=tg2rub
Group=tg2rub
WorkingDirectory=$APP
Environment=PYTHONUNBUFFERED=1
ExecStart=$APP/venv/bin/python $APP/bot.py
Restart=on-failure
RestartSec=5
TimeoutStopSec=30
NoNewPrivileges=true
ProtectSystem=strict
ProtectHome=true
ReadWritePaths=$ROOT
PrivateTmp=true
[Install]
WantedBy=multi-user.target
UNIT

systemctl daemon-reload
systemctl enable tgapi
if systemctl is-active --quiet tgapi; then
  systemctl restart tgapi
else
  systemctl start tgapi
fi
if systemctl is-active --quiet tg2rub; then
  systemctl restart tg2rub
fi

cat <<'MSG'

INSTALLATION BASE READY.
No C++ compilation was performed on this VPS.
Next:
1) If this bot was previously using api.telegram.org, run once:
   tg2rub-logout-cloud
2) Log in to Rubika:
   runuser -u tg2rub -- /opt/tg2rub/app/venv/bin/python /opt/tg2rub/app/login_rubika.py
3) Start the bridge:
   systemctl enable --now tg2rub
4) Check logs:
   journalctl -u tg2rub -n 60 --no-pager

The installer preserves complete existing credentials and refuses partial credential state.
MSG
