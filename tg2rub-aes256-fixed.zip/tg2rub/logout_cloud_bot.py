#!/usr/bin/env python3
"""Call Telegram Bot API logOut without displaying the bot token."""
import json
import re
import sys
import urllib.parse
import urllib.request
from pathlib import Path

ENV = Path('/opt/tg2rub/app/.env')
if not ENV.is_file():
    sys.exit('App configuration not found.')
values = {}
for line in ENV.read_text(encoding='utf-8').splitlines():
    if '=' in line and not line.lstrip().startswith('#'):
        key, value = line.split('=', 1)
        values[key.strip()] = value.strip()
token = values.get('BOT_TOKEN', '')
if not re.fullmatch(r'[0-9]{6,}:[A-Za-z0-9_-]{20,}', token):
    sys.exit('Bot token is missing or has an invalid format; no request was sent.')
url = f'https://api.telegram.org/bot{token}/logOut'
request = urllib.request.Request(url, data=urllib.parse.urlencode({}).encode(), method='POST')
try:
    with urllib.request.urlopen(request, timeout=30) as response:
        payload = json.loads(response.read().decode('utf-8'))
    if payload.get('ok') and payload.get('result') is True:
        print('Telegram cloud Bot API logout succeeded. You can now start the local Bot API.')
    else:
        print('Telegram returned an unsuccessful logOut response. Token was not displayed.')
        sys.exit(2)
except Exception as exc:
    print(f'Telegram logOut request failed ({type(exc).__name__}). Token was not displayed.')
    sys.exit(3)
