import tempfile
import unittest
import zipfile
try:
    import pyzipper
except ImportError:
    pyzipper = None
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from fileops import link_or_copy, make_zip, safe_name, split_file


class FileOpsTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.root = Path(self.tmp.name)
        self.src = self.root / "sample.bin"
        self.payload = bytes(range(256)) * 8193 + b"tail"
        self.src.write_bytes(self.payload)

    def tearDown(self):
        self.tmp.cleanup()

    def test_split_exact_reconstruction(self):
        for count in (1, 2, 3, 7, 50):
            with self.subTest(count=count):
                for old in self.root.glob("sample.bin.[0-9][0-9][0-9]"):
                    old.unlink()
                parts = split_file(self.src, count)
                self.assertTrue(parts)
                self.assertEqual(b"".join(p.read_bytes() for p in parts), self.payload)
                self.assertEqual(sum(p.stat().st_size for p in parts), len(self.payload))

    def test_split_count_larger_than_file_size(self):
        tiny = self.root / "tiny.bin"
        tiny.write_bytes(b"abc")
        parts = split_file(tiny, 50)
        self.assertEqual(len(parts), 3)
        self.assertEqual(b"".join(p.read_bytes() for p in parts), b"abc")
        self.assertTrue(all(p.stat().st_size > 0 for p in parts))

    def test_empty_split_rejected(self):
        empty = self.root / "empty"
        empty.write_bytes(b"")
        with self.assertRaises(ValueError):
            split_file(empty, 2)

    def test_zip_store_and_deflate(self):
        for level in (0, 1, 6, 9):
            dst = self.root / f"sample-{level}.zip"
            make_zip(self.src, "sample.bin", dst, level)
            with zipfile.ZipFile(dst) as archive:
                self.assertEqual(archive.read("sample.bin"), self.payload)


    @unittest.skipIf(pyzipper is None, "pyzipper not installed in this test environment")
    def test_aes256_zip_round_trip(self):
        dst = self.root / "encrypted.zip"
        make_zip(self.src, "sample.bin", dst, 0, "Strong-passphrase-2026")
        with pyzipper.AESZipFile(dst) as archive:
            self.assertEqual(archive.getinfo("sample.bin").wz_aes_strength, 3)
            archive.setpassword(b"Strong-passphrase-2026")
            self.assertEqual(archive.read("sample.bin"), self.payload)
        with pyzipper.AESZipFile(dst) as archive:
            archive.setpassword(b"incorrect-password")
            with self.assertRaises((RuntimeError, pyzipper.zipfile.BadZipFile)):
                archive.read("sample.bin")

    @unittest.skipIf(pyzipper is None, "pyzipper not installed in this test environment")
    def test_aes_zip_rejects_short_password(self):
        with self.assertRaises(ValueError):
            make_zip(self.src, "sample.bin", self.root / "bad.zip", 0, "short")

    def test_link_or_copy_preserves_content(self):
        dst = self.root / "copy.bin"
        link_or_copy(self.src, dst)
        self.assertEqual(dst.read_bytes(), self.payload)

    def test_safe_filename(self):
        self.assertEqual(safe_name("../../secret.txt"), "secret.txt")
        self.assertNotIn("/", safe_name("a/b\\c?.txt"))
        self.assertEqual(safe_name("..."), "file")


if __name__ == "__main__":
    unittest.main()
