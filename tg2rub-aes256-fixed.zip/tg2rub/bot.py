#!/usr/bin/env python3
"""tg2rub - Telegram bot -> Rubika (Saved Messages) uploader.

Telegram side : official Bot API only (local telegram-bot-api server, so no 20MB limit)
Rubika side   : your own account, logged in once with phone + code (rubpy)
"""
from __future__ import annotations

import asyncio
import logging
import math
import os
import json
import tempfile
import re
import secrets
import shutil
import time
from contextlib import AsyncExitStack
from dataclasses import dataclass, field
from functools import wraps
from pathlib import Path

from dotenv import load_dotenv
from rubpy import Client as Rubika
from telegram import InlineKeyboardButton as Btn, InlineKeyboardMarkup as Markup, Update
from telegram.error import BadRequest
from telegram.ext import (ApplicationBuilder, CallbackQueryHandler, CommandHandler,
                          ContextTypes, MessageHandler, filters)
from fileops import link_or_copy, make_zip, safe_name, split_file

BASE = Path(__file__).resolve().parent
os.umask(0o077)  # downloaded source files, split parts and metadata are private by default
os.chdir(BASE)  # rubpy session file lives next to the code
load_dotenv(BASE / ".env")

# ---------------------------------------------------------------- config
BOT_TOKEN = os.environ["BOT_TOKEN"]
ADMIN_IDS = {int(x) for x in os.environ["ADMIN_IDS"].replace(" ", "").split(",") if x}
API_BASE = os.getenv("API_BASE", "http://127.0.0.1:8081").rstrip("/")
WORK_DIR = Path(os.getenv("WORK_DIR", "/opt/tg2rub/work"))
MAX_FILE = int(float(os.getenv("MAX_FILE_GB", "4")) * 1024 ** 3)
RUBIKA_MAX = int(os.getenv("RUBIKA_MAX_MB", "2000")) * 1024 ** 2   # auto-split above this
AUTO_DELETE = os.getenv("AUTO_DELETE", "1") == "1"
ZIP_LEVEL = int(os.getenv("ZIP_LEVEL", "1"))        # 0 = store (fastest), 1-9 = deflate
UPLOAD_TIMEOUT = int(os.getenv("UPLOAD_TIMEOUT_MIN", "180")) * 60
UPLOAD_RETRIES = max(1, min(int(os.getenv("UPLOAD_RETRIES", "3")), 5))
UPLOAD_RETRY_BASE = max(1, min(int(os.getenv("UPLOAD_RETRY_BASE_SEC", "5")), 60))
STALE_HOURS = int(os.getenv("STALE_HOURS", "24"))
SESSION_NAME = "rubika"
if MAX_FILE <= 0 or RUBIKA_MAX <= 0 or not 0 <= ZIP_LEVEL <= 9:
    raise RuntimeError("Invalid MAX_FILE_GB, RUBIKA_MAX_MB or ZIP_LEVEL configuration")
if UPLOAD_TIMEOUT <= 0 or STALE_HOURS <= 0:
    raise RuntimeError("UPLOAD_TIMEOUT_MIN and STALE_HOURS must be positive")


class SecretRedactionFilter(logging.Filter):
    _patterns = [
        (re.compile(r"\b[0-9]{6,}:[A-Za-z0-9_-]{20,}\b"), "<BOT_TOKEN_REDACTED>"),
        (re.compile(r"-----BEGIN [A-Z ]*PRIVATE KEY-----.*?-----END [A-Z ]*PRIVATE KEY-----", re.S),
         "<PRIVATE_KEY_REDACTED>"),
    ]

    def filter(self, record):
        try:
            message = record.getMessage()
            for pattern, replacement in self._patterns:
                message = pattern.sub(replacement, message)
            record.msg, record.args = message, ()
        except Exception:
            record.msg, record.args = "<log message redacted>", ()
        return True


logging.basicConfig(format="%(asctime)s %(levelname)s %(message)s", level=logging.INFO)
for handler in logging.getLogger().handlers:
    handler.addFilter(SecretRedactionFilter())
for noisy in ("httpx", "httpcore", "apscheduler", "rubpy", "rubpy.network", "rubpy.session", "pyrogram", "pyrogram.session", "pyrogram.crypto"):
    logging.getLogger(noisy).setLevel(logging.WARNING)
log = logging.getLogger("tg2rub")

RUBIKA: Rubika | None = None
STACK = AsyncExitStack()
LOCK: asyncio.Lock | None = None   # created in post_init (one heavy job at a time)


# ---------------------------------------------------------------- model
@dataclass
class Job:
    id: str
    dir: Path
    src: Path
    name: str
    size: int
    chat_id: int
    msg_id: int = 0
    zip: bool = False
    zip_password: str | None = field(default=None, repr=False)  # memory only; never persisted
    zip_password_required: bool = False  # persisted flag; prevents silent unencrypted fallback after restart
    parts: int = 1
    auto_delete: bool = AUTO_DELETE
    busy: bool = False
    sent_parts: list[str] = field(default_factory=list)
    pending_part: str | None = None
    output_signature: str | None = None
    ts: float = field(default_factory=time.time)


JOBS: dict[str, Job] = {}


# ---------------------------------------------------------------- helpers
def human(n: float) -> str:
    for u in ("B", "KB", "MB", "GB"):
        if n < 1024:
            return f"{n:.1f} {u}"
        n /= 1024
    return f"{n:.1f} TB"


def admin_only(fn):
    @wraps(fn)
    async def wrapper(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        u = update.effective_user
        if not u or u.id not in ADMIN_IDS:
            return  # silently ignore strangers
        return await fn(update, ctx)
    return wrapper


def card(j: Job) -> str:
    n_parts = j.parts
    out = j.name + (".zip" if j.zip else "")
    if n_parts > 1:
        out += f"  →  {n_parts} قسمت (.001 …)"
    return (f"📄 {j.name}\n📦 حجم: {human(j.size)}\n"
            f"🗜 ZIP: {'روشن' if j.zip else 'خاموش'}\n"
            f"🔐 رمز ZIP: {'فعال (AES-256)' if j.zip_password else ('نیازمند ورود مجدد' if j.zip_password_required else 'بدون رمز')}\n"
            f"✂️ تقسیم: {n_parts if n_parts > 1 else 'خاموش'}\n"
            f"🧹 حذف خودکار بعد آپلود: {'بله' if j.auto_delete else 'خیر'}\n\n"
            f"خروجی: {out}")


def keyboard(j: Job) -> Markup:
    i = j.id
    return Markup([
        [Btn("✏️ تغییر نام", callback_data=f"rn:{i}"),
         Btn("🗜 ZIP", callback_data=f"zp:{i}")],
        [Btn("🔐 تنظیم رمز ZIP", callback_data=f"pw:{i}"),
         Btn("🔓 حذف رمز", callback_data=f"p0:{i}")],
        [Btn("✂️ تقسیم به چند قسمت", callback_data=f"sp:{i}"),
         Btn("🧹 حذف بعد آپلود", callback_data=f"ad:{i}")],
        ([Btn("⚠️ تلاش مجدد با احتمال ارسال تکراری", callback_data=f"fr:{i}")]
         if j.pending_part else [Btn("🚀 آپلود به روبیکا", callback_data=f"up:{i}")]),
        [Btn("🗑 حذف از سرور", callback_data=f"rm:{i}")],
    ])


async def refresh(bot, j: Job, text: str | None = None, buttons: bool = True):
    try:
        await bot.edit_message_text(chat_id=j.chat_id, message_id=j.msg_id,
                                    text=text or card(j),
                                    reply_markup=keyboard(j) if buttons else None)
    except Exception as e:
        # Do not let a Telegram status-message failure strand a job in busy state.
        if not isinstance(e, BadRequest) or "not modified" not in str(e).lower():
            log.warning("Telegram message edit failed (%s)", type(e).__name__)


def job_metadata(j: Job) -> dict:
    return {
        "id": j.id, "name": j.name, "size": j.size,
        "chat_id": j.chat_id, "msg_id": j.msg_id,
        "zip": j.zip, "zip_password_required": j.zip_password_required or bool(j.zip_password), "parts": j.parts,
        "auto_delete": j.auto_delete, "sent_parts": j.sent_parts,
        "pending_part": j.pending_part, "output_signature": j.output_signature,
        "ts": j.ts,
    }


def persist_job(j: Job) -> None:
    """Atomically persist recoverable job state; never persist credentials."""
    j.dir.mkdir(parents=True, exist_ok=True)
    target = j.dir / "job.json"
    fd, tmp_name = tempfile.mkstemp(prefix=".job-", suffix=".tmp", dir=j.dir)
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as f:
            json.dump(job_metadata(j), f, ensure_ascii=False)
            f.flush()
            os.fsync(f.fileno())
        os.replace(tmp_name, target)
        os.chmod(target, 0o600)
    except Exception:
        try:
            os.unlink(tmp_name)
        except OSError:
            pass
        raise


def restore_jobs() -> None:
    """Restore only jobs with valid metadata and an existing source file."""
    JOBS.clear()
    for meta in WORK_DIR.glob("*/job.json"):
        try:
            data = json.loads(meta.read_text(encoding="utf-8"))
            jid = str(data["id"])
            jdir = meta.parent.resolve()
            if not re.fullmatch(r"[0-9a-f]{8}", jid) or jdir.parent != WORK_DIR.resolve():
                continue
            src = (jdir / "src.bin").resolve()
            if src.parent != jdir or not src.is_file() or src.stat().st_size <= 0:
                continue
            j = Job(
                id=jid, dir=jdir, src=src,
                name=safe_name(str(data.get("name", "file"))),
                size=src.stat().st_size,
                chat_id=int(data["chat_id"]), msg_id=int(data.get("msg_id", 0)),
                zip=bool(data.get("zip", False)),
                zip_password_required=bool(data.get("zip_password_required", False)),
                parts=max(1, min(int(data.get("parts", 1)), 50)),
                auto_delete=bool(data.get("auto_delete", AUTO_DELETE)),
                busy=False,
                sent_parts=[str(x) for x in data.get("sent_parts", []) if isinstance(x, str)],
                pending_part=(str(data["pending_part"]) if data.get("pending_part") else None),
                output_signature=(str(data["output_signature"]) if data.get("output_signature") else None),
                ts=float(data.get("ts", time.time())),
            )
            JOBS[jid] = j
        except Exception as exc:
            log.warning("skipping invalid saved job metadata (%s)", type(exc).__name__)
    if JOBS:
        log.info("restored %d pending file job(s)", len(JOBS))


def drop(j: Job):
    JOBS.pop(j.id, None)
    shutil.rmtree(j.dir, ignore_errors=True)


# ---------------------------------------------------------------- upload
def is_retryable_rubika_error(exc: Exception) -> bool:
    """Retry only explicit transient server responses; never retry arbitrary failures."""
    msg = str(exc).upper()
    return "ERROR_TRY_AGAIN" in msg


def safe_error(exc: Exception) -> str:
    """Return a short user-facing error without dumping request/session internals."""
    msg = str(exc)
    if "رمز ZIP پس از راه‌اندازی مجدد" in msg:
        return "برای حفظ رمزگذاری، پس از راه‌اندازی مجدد باید رمز ZIP را دوباره تنظیم کنی."
    if "ERROR_TRY_AGAIN" in msg or "SERVER_ERROR" in msg:
        return "روبیکا درخواست ایجاد فایل را با خطای موقت SERVER_ERROR رد کرد."
    if isinstance(exc, asyncio.TimeoutError):
        return "مهلت آپلود تمام شد؛ وضعیت نهایی ارسال از سمت روبیکا مشخص نیست."
    return f"خطای {type(exc).__name__}؛ جزئیات فنی در پیام کاربر نمایش داده نمی‌شود."


async def upload_one(path: Path):
    size = path.stat().st_size
    log.info("upload start: size=%d suffix=%r", size, path.suffix)
    for attempt in range(1, UPLOAD_RETRIES + 1):
        try:
            await asyncio.wait_for(
                RUBIKA.send_document("me", str(path), caption=path.name),
                timeout=UPLOAD_TIMEOUT)
            return
        except Exception as exc:
            if not is_retryable_rubika_error(exc) or attempt >= UPLOAD_RETRIES:
                log.warning("upload failed: size=%d attempt=%d/%d type=%s",
                            size, attempt, UPLOAD_RETRIES, type(exc).__name__)
                raise
            delay = min(UPLOAD_RETRY_BASE * (2 ** (attempt - 1)), 60)
            log.warning("temporary Rubika error: attempt=%d/%d; retry in %ds",
                        attempt, UPLOAD_RETRIES, delay)
            await asyncio.sleep(delay)


# ---------------------------------------------------------------- pipeline
async def process(bot, j: Job):
    j.busy = True                       # block double-clicks while queued
    await refresh(bot, j, "⏳ در صف…", buttons=False)
    async with LOCK:
        out = j.dir / "out"
        try:
            # Check before comparing signatures: after restart the password is
            # intentionally absent from memory. Do not erase confirmed upload
            # progress until the administrator re-enters the same password.
            if j.zip and j.zip_password_required and not j.zip_password:
                raise RuntimeError("رمز ZIP پس از راه‌اندازی مجدد در حافظه نیست؛ ابتدا دوباره تنظیمش کن")
            password_mode = "aes256" if j.zip_password else ("required" if j.zip_password_required else "none")
            signature = (f"{j.name}|{int(j.zip)}|{j.parts}|{ZIP_LEVEL}|{RUBIKA_MAX}|{password_mode}|"
                         f"{j.src.stat().st_size}|{j.src.stat().st_mtime_ns}")
            if j.output_signature != signature:
                j.sent_parts.clear()
                j.pending_part = None
                j.output_signature = signature
                persist_job(j)
            splitting = j.parts > 1 or j.size > RUBIKA_MAX
            need = j.size * (int(j.zip) + int(splitting)) + (64 << 20)
            if shutil.disk_usage(WORK_DIR).free < need:
                raise RuntimeError(f"فضای دیسک کافی نیست (حدود {human(need)} لازم است)")

            shutil.rmtree(out, ignore_errors=True)
            out.mkdir()
            await refresh(bot, j, "⚙️ در حال آماده‌سازی…", buttons=False)

            if j.zip:
                target = out / (j.name + ".zip")
                await asyncio.to_thread(make_zip, j.src, j.name, target, ZIP_LEVEL, j.zip_password)
            else:
                target = out / j.name
                await asyncio.to_thread(link_or_copy, j.src, target)

            parts = j.parts
            if parts == 1 and target.stat().st_size > RUBIKA_MAX:
                parts = math.ceil(target.stat().st_size / RUBIKA_MAX)
            files = [target]
            if parts > 1:
                await refresh(bot, j, f"✂️ در حال تقسیم به {parts} قسمت…", buttons=False)
                files = await asyncio.to_thread(split_file, target, parts)
                target.unlink()

            for i, p in enumerate(files, 1):
                # A successful response is persisted so a later retry does not resend
                # already-confirmed parts. A timeout remains ambiguous and is not retried.
                if p.name in j.sent_parts:
                    p.unlink(missing_ok=True)
                    continue
                if j.pending_part == p.name:
                    raise RuntimeError("Previous upload result is uncertain; explicit retry confirmation is required")
                sz = p.stat().st_size
                await refresh(bot, j, f"📤 آپلود {i}/{len(files)}\n{p.name}\n{human(sz)}",
                              buttons=False)
                # Persist intent before network I/O. If the process dies after the
                # remote side accepted the file but before acknowledgment, we will
                # ask for explicit retry confirmation instead of blindly duplicating.
                j.pending_part = p.name
                persist_job(j)
                t0 = time.monotonic()
                try:
                    await upload_one(p)
                except Exception as upload_exc:
                    if "ERROR_TRY_AGAIN" in str(upload_exc).upper():
                        j.pending_part = None  # explicit server rejection, not ambiguous
                        persist_job(j)
                    raise
                dt = max(time.monotonic() - t0, 0.001)
                j.sent_parts.append(p.name)
                j.pending_part = None
                persist_job(j)
                log.info("uploaded part %d/%d size=%s in %.0fs (%s/s)",
                         i, len(files), human(sz), dt, human(sz / dt))
                p.unlink()

            shutil.rmtree(out, ignore_errors=True)
            if j.auto_delete:
                chat_id, msg_id, done_name = j.chat_id, j.msg_id, j.name
                drop(j)
                try:
                    await bot.edit_message_text(chat_id=chat_id, message_id=msg_id,
                                                text=f"✅ آپلود شد و از سرور حذف شد.\n{done_name}")
                except Exception as edit_exc:
                    log.warning("completion message edit failed (%s)", type(edit_exc).__name__)
            else:
                # Keep the source for a deliberate future re-send; clear only the
                # completed-run markers so the next explicit click sends it again.
                j.sent_parts.clear()
                j.busy = False
                persist_job(j)
                await refresh(bot, j, "✅ آپلود شد (فایل هنوز روی سرور است)\n\n" + card(j))
        except asyncio.CancelledError:
            raise
        except Exception as e:
            # Avoid full Rubpy traceback/response in logs; it may expose request/session details.
            error_text = safe_error(e)
            if j.pending_part:
                error_text = (f"نتیجه ارسال قطعه «{j.pending_part}» نامشخص است؛ "
                              "ممکن است روبیکا آن را دریافت کرده باشد. "
                              "برای تلاش مجدد، دکمه هشدار را آگاهانه بزن؛ احتمال ارسال تکراری وجود دارد.")
            log.error("job %s failed: %s", j.id, error_text)
            shutil.rmtree(out, ignore_errors=True)
            j.busy = False
            persist_job(j)
            await refresh(bot, j, f"❌ خطا: {error_text}\n\n" + card(j))
        finally:
            j.busy = False
            j.ts = time.time()
            if JOBS.get(j.id) is j:
                try:
                    persist_job(j)
                except Exception as persist_exc:
                    log.error("could not persist job state (%s)", type(persist_exc).__name__)


# ---------------------------------------------------------------- handlers
HELP = ("سلام 👋\nفایل (تا ۴ گیگ) را بفرست؛ بعد با دکمه‌ها نام، ZIP و تقسیم را تنظیم کن "
        "و آپلود به روبیکا (Saved Messages) را بزن.\n\n"
        "/list فایل‌های روی سرور\n/disk فضای دیسک\n/clean حذف همه فایل‌ها از سرور\n"
        "/test تست اتصال روبیکا\n/cancel لغو ورودی در حال انتظار")

EXT = {"video": ".mp4", "audio": ".mp3", "voice": ".ogg", "video_note": ".mp4",
       "photo": ".jpg", "animation": ".mp4"}


@admin_only
async def cmd_start(update: Update, ctx):
    await update.message.reply_text(HELP)


@admin_only
async def cmd_list(update: Update, ctx):
    if not JOBS:
        return await update.message.reply_text("هیچ فایلی روی سرور نیست.")
    rows = [[Btn(f"{j.name} ({human(j.size)})"[:60], callback_data=f"op:{j.id}")]
            for j in JOBS.values()]
    await update.message.reply_text("فایل‌های روی سرور:", reply_markup=Markup(rows))


@admin_only
async def cmd_disk(update: Update, ctx):
    d = shutil.disk_usage(WORK_DIR)
    used = sum(j.size for j in JOBS.values())
    await update.message.reply_text(f"💾 آزاد: {human(d.free)} از {human(d.total)}\n"
                                    f"فایل‌های ربات: {len(JOBS)} ({human(used)})")


@admin_only
async def cmd_clean(update: Update, ctx):
    busy = [j for j in JOBS.values() if j.busy]
    n = 0
    for j in list(JOBS.values()):
        if not j.busy:
            drop(j)
            n += 1
    # With concurrent_updates disabled, no download handler can be active here.
    # Keep directories belonging to still-running jobs; remove crash leftovers.
    known_dirs = {j.dir.resolve() for j in JOBS.values() if j.busy}
    orphan_count = 0
    for child in WORK_DIR.iterdir():
        if child.is_dir() and child.resolve() not in known_dirs:
            shutil.rmtree(child, ignore_errors=True)
            orphan_count += 1
    await update.message.reply_text(
        f"🗑 {n} فایل و {orphan_count} پوشه موقت حذف شد." +
        (" (فایل در حال پردازش دست‌نخورده ماند)" if busy else ""))


@admin_only
async def cmd_test(update: Update, ctx):
    try:
        await asyncio.wait_for(RUBIKA.send_message("me", "✅ tg2rub test"), 30)
        await update.message.reply_text("✅ اتصال روبیکا سالم است (پیام در Saved Messages).")
    except Exception as e:
        await update.message.reply_text(f"❌ {safe_error(e)}")


@admin_only
async def cmd_cancel(update: Update, ctx):
    ctx.user_data.pop("await", None)
    await update.message.reply_text("لغو شد.")


@admin_only
async def on_file(update: Update, ctx):
    m = update.effective_message
    kind = next((k for k in ("document", "video", "audio", "voice", "video_note", "animation")
                 if getattr(m, k)), "photo" if m.photo else None)
    if not kind:
        return
    att = m.photo[-1] if kind == "photo" else getattr(m, kind)
    size = att.file_size or 0
    if size > MAX_FILE:
        return await m.reply_text(f"❌ حجم بیشتر از {human(MAX_FILE)} است.")
    # If Telegram omits file_size, reserve against the configured maximum rather
    # than assuming the incoming file is tiny.
    expected_size = size if size > 0 else MAX_FILE
    if shutil.disk_usage(WORK_DIR).free < expected_size * 1.1 + (256 << 20):
        return await m.reply_text("❌ فضای دیسک سرور برای دریافت امن فایل کافی نیست. /clean بزن.")

    name = safe_name(getattr(att, "file_name", None) or f"{att.file_unique_id}{EXT.get(kind, '')}")
    status = await m.reply_text(f"⏬ در حال دریافت از تلگرام…\n{name} ({human(size)})")
    jid = secrets.token_hex(4)
    jdir = WORK_DIR / jid
    jdir.mkdir(parents=True)
    try:
        f = await att.get_file(read_timeout=7200, write_timeout=120,
                               connect_timeout=30, pool_timeout=60)
        if f.file_path.startswith("http"):
            raise RuntimeError("سرور محلی Bot API فعال نیست (فایل بزرگ قابل دریافت نیست)")
        src = jdir / "src.bin"
        await asyncio.to_thread(shutil.move, f.file_path, str(src))
        if not src.is_file():
            raise RuntimeError("فایل دریافتی در مسیر موقت پیدا نشد.")
        actual_size = src.stat().st_size
        if actual_size <= 0:
            raise RuntimeError("فایل دریافتی خالی است.")
        if actual_size > MAX_FILE:
            raise RuntimeError(f"حجم واقعی فایل بیشتر از سقف مجاز ({human(MAX_FILE)}) است.")
    except Exception as e:
        shutil.rmtree(jdir, ignore_errors=True)
        # Do not echo raw exception text: Bot API URLs can contain the bot token.
        log.error("download failed: %s", type(e).__name__)
        return await status.edit_text(
            f"❌ دریافت فایل ناموفق بود ({type(e).__name__}). "
            "جزئیات حساس در پیام یا لاگ عمومی نمایش داده نمی‌شود."
        )

    j = Job(jid, jdir, src, name, src.stat().st_size, status.chat_id, status.message_id)
    JOBS[jid] = j
    persist_job(j)
    await refresh(ctx.bot, j)


@admin_only
async def on_button(update: Update, ctx):
    q = update.callback_query
    act, _, jid = q.data.partition(":")
    j = JOBS.get(jid)
    if not j:
        return await q.answer("این فایل دیگر روی سرور نیست.", show_alert=True)
    if j.busy:
        return await q.answer("در حال پردازش…")
    await q.answer()
    j.ts = time.time()

    if act == "op":           # reopen card from /list
        m = await q.message.reply_text(card(j), reply_markup=keyboard(j))
        j.chat_id, j.msg_id = m.chat_id, m.message_id
        persist_job(j)
    elif act == "zp":
        j.zip = not j.zip
        j.sent_parts.clear()
        j.pending_part = None
        persist_job(j)
        await refresh(ctx.bot, j)
    elif act == "ad":
        j.auto_delete = not j.auto_delete
        persist_job(j)
        await refresh(ctx.bot, j)
    elif act == "p0":
        j.zip_password = None
        j.zip_password_required = False
        j.sent_parts.clear()
        j.pending_part = None
        j.output_signature = None
        persist_job(j)
        await refresh(ctx.bot, j, "🔓 رمز ZIP حذف شد. خروجی بعدی بدون رمز ساخته می‌شود.")
    elif act == "pw":
        ctx.user_data["await"] = ("pw", jid)
        await q.message.reply_text(
            "🔐 رمز ZIP را بفرست (۸ تا ۱۲۸ نویسه). پیام رمز بلافاصله پس از دریافت حذف می‌شود. برای لغو /cancel بزن."
        )
    elif act == "rn":
        ctx.user_data["await"] = ("rn", jid)
        await q.message.reply_text("✏️ نام جدید را بفرست.\n(اگر پسوند ننویسی، پسوند قبلی حفظ می‌شود) — /cancel")
    elif act == "sp":
        ctx.user_data["await"] = ("sp", jid)
        await q.message.reply_text("✂️ به چند قسمت تقسیم شود؟ (عدد ۱ تا ۵۰، عدد ۱ یعنی بدون تقسیم) — /cancel")
    elif act == "up":
        await process(ctx.bot, j)
    elif act == "fr":
        # The user explicitly accepts the possibility of a duplicate upload.
        j.pending_part = None
        persist_job(j)
        await process(ctx.bot, j)
    elif act == "rm":
        drop(j)
        await q.edit_message_text("🗑 از سرور حذف شد.")


@admin_only
async def on_text(update: Update, ctx):
    st = ctx.user_data.pop("await", None)
    if not st:
        return
    kind, jid = st
    j = JOBS.get(jid)
    if not j or j.busy:
        return await update.message.reply_text("این فایل دیگر در دسترس نیست.")
    raw_text = update.message.text or ""
    t = raw_text if kind == "pw" else raw_text.strip()
    if kind == "pw":
        try:
            await update.message.delete()  # remove the password message before any further processing
        except Exception:
            log.warning("could not delete ZIP password message; ask admin to delete it manually")
    if kind == "rn":
        new = safe_name(t, j.name)
        if not Path(new).suffix and Path(j.name).suffix:
            new += Path(j.name).suffix
        if new != j.name:
            j.name = new
            j.sent_parts.clear()
            j.pending_part = None
    elif kind == "pw":
        if not 8 <= len(t) <= 128:
            ctx.user_data["await"] = st
            return await update.message.reply_text("رمز باید بین ۸ تا ۱۲۸ نویسه باشد؛ دوباره بفرست یا /cancel کن.")
        j.zip_password = t
        j.zip_password_required = True
        j.zip = True
        j.sent_parts.clear()
        j.pending_part = None
        j.output_signature = None
    elif kind == "sp":
        if not t.isdigit() or not 1 <= int(t) <= 50:
            ctx.user_data["await"] = st
            return await update.message.reply_text("یک عدد بین ۱ تا ۵۰ بفرست.")
        new_parts = int(t)
        if new_parts != j.parts:
            j.parts = new_parts
            j.sent_parts.clear()
            j.pending_part = None
    persist_job(j)
    await refresh(ctx.bot, j)
    try:
        await update.message.delete()
    except Exception:
        pass


async def janitor(ctx):
    now = time.time()
    for j in list(JOBS.values()):
        if not j.busy and now - j.ts > STALE_HOURS * 3600:
            log.info("dropping stale job %s", j.id)
            drop(j)


# ---------------------------------------------------------------- lifecycle
async def post_init(app):
    global RUBIKA, LOCK
    LOCK = asyncio.Lock()
    WORK_DIR.mkdir(parents=True, exist_ok=True)
    restore_jobs()  # never erase user files on service restart
    if not list(BASE.glob(f"{SESSION_NAME}*")):
        raise SystemExit("Rubika session not found. Run:  python login_rubika.py")
    RUBIKA = await STACK.enter_async_context(Rubika(name=SESSION_NAME))
    log.info("Rubika connected; bot ready")


async def post_shutdown(app):
    await STACK.aclose()


def main():
    app = (ApplicationBuilder().token(BOT_TOKEN)
           .base_url(f"{API_BASE}/bot").base_file_url(f"{API_BASE}/file/bot")
           .local_mode(True).concurrent_updates(False)
           .read_timeout(60).write_timeout(60).connect_timeout(20).pool_timeout(20)
           .post_init(post_init).post_shutdown(post_shutdown).build())
    priv = filters.ChatType.PRIVATE
    for cmd, fn in (("start", cmd_start), ("help", cmd_start), ("list", cmd_list),
                    ("disk", cmd_disk), ("clean", cmd_clean), ("test", cmd_test),
                    ("cancel", cmd_cancel)):
        app.add_handler(CommandHandler(cmd, fn, filters=priv))
    media = (filters.Document.ALL | filters.VIDEO | filters.AUDIO | filters.VOICE |
             filters.VIDEO_NOTE | filters.ANIMATION | filters.PHOTO)
    app.add_handler(MessageHandler(priv & media, on_file))
    app.add_handler(MessageHandler(priv & filters.TEXT & ~filters.COMMAND, on_text))
    app.add_handler(CallbackQueryHandler(on_button))
    app.job_queue.run_repeating(janitor, 1800, first=120)
    app.run_polling(allowed_updates=["message", "callback_query"], drop_pending_updates=False)


if __name__ == "__main__":
    main()
